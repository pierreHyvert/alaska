Bonjour, 
vous trouverez dans alaska-siteData.zip les fichiers et la bdd pour faire fonctionner le site en local, la connexion bdd est configur�e pour wamp (fichier Manager.php dans le dossier model).

J'ai mis �galement des exports de mon �tude pr�liminaire sur la charte graphique (qui a un peu �volu� entre temps).

L'�tude sur le zoning est visible ici : https://www.draw.io/#G1wiMf1uXfdkh27klYr2V7p1u0SrbYm3h8
De m�me le r�sultat final a un peu �volu�.

Lien vers le d�pot Git :
https://github.com/pierreHyvert/alaska

Lien vers le site en ligne :
http://alaska.webmetrue.fr/


Le login � utiliser pour acc�der � l'admin est "phyvert@wanadoo.fr" et le mdp est "heycoucou"


Bien � vous,
Pierre Hyvert