<?php
class Post {
  private $_prevPostId = 0;
  private $_prevPostTitle = '';
  private $_nextPostId = 0;
  private $_nextPostTitle = '';



  //getters


  //setters
}
