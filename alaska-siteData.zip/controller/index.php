<?php
header("Location: http://www.webmetrue.com/alaska");
exit;
?>
