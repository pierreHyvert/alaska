<?php
header("Location: http://www.alaska.webmetrue.com");
exit;
?>
