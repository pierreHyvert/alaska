<?php
require_once('view/frontend/header.php');
?>
<section id="contenu" class="">
<?= $content ?>
</section>
<?php
require_once('view/frontend/footer.php');
?>
