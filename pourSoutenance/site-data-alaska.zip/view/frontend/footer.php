</div>
<!-- Ferme la section Page -->
<footer class="page-footer bleuclair">
  <div class="footer-copyright">
    <div class="container">&copy; Jean Forteroche -  <a class="white-text" href="index.php?action=mentions" title="mentions légales">Mentions légales</a>
    </div>
  </div>
</footer>
<script src="<?= $racine ?>/public/js/jquery-3.3.1.min.js"></script>
<script src="<?= $racine ?>/public/js/materialize.min.js"></script>
<script src="<?= $racine ?>/public/js/slick.min.js"></script>
<script src="<?= $racine ?>/public/js/init.js"></script>
<script src="<?= $racine ?>/public/js/ajax.js"></script>
<script src="<?= $racine ?>/public/js/functions.js"></script>

</body>
</html>
